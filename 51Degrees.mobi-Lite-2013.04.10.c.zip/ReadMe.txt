Introduction
------------

Use this project to detect device properties using HTTP browser user agents as
input. It can be used to process server log files, or for real time device
detection to support web optimisation.

Two detection methods are supported.

Pattern		Utilises regular expressions and levenshtein distance string
			matching. All logic and data compiled into a single C library. Can
			take upto 10 minutes to compile. Very memory efficient.

Trie		A large binary trie (pronounced Try) populated with device
			patterns. Uses a separate data file. Very fast.

This package includes the follow examples:

1.	Command line process which takes a user agent via stdin and return a device
	id via stdout. Can easily be modified to return other properties.

2.	Command line performance evaluation programme which takes a file of user
	agents and returns a performance score measured in detections per second
	per CPU core.

3.	A windows only multi-threaded trie matching method performance evaluation
	programme.

4.  A windows example web site which uses the 2 detection methods and compares
	the results side by side for the requesting browser.

Use the following instructions to compile different versions for different
target platforms.

Included Files
--------------

Win32build.bat - Builds command line executable in 32 bit windows.
Win64build.bat - Builds command line executable in 64 bit windows.
WinGCCbuild.bat - Builds command line executable using GCC for windows.
makefile - Builds a command line executable under Linux.
Licence.txt - The licence terms for the files in this zip file.

data - folder to place the trie data file which needs to be downloaded
	separatly. See separate readme for download locations.

src/ - all generic C files used across multiple platforms.

src/pattern - all source files related to Pattern matching detection.

	51Degrees.mobi.h - The header file for the core detection library.
	51Degrees.mobi.c - All the code and necessary data. Quite large.
	ProcPat.c - The command line interface wrapper.
	PerfPat.c - The command line performance test executable.

src/pattern/pcre/ - modified versions of the PCRE regular expression library.

	* - file associated with PCRE library.

src/trie - all source files related to Trie matching detection.

	51Degrees.mobi.h - The header file for the core detection library.
	51Degrees.mobi.c - Source code needed to interrogate the data.
	ProcTrie.c - The command line interface wrapper.
	PerfTrie.c - The command line performance test executable.

windows/ - all files related exclusively to Windows.

	Interop/FiftyOne.Mobile.Detection.Provider.Interop.csproj - C# project.
	Interop/PatternWrapper.cs - C# class used to wrap and expose pattern
		matching library to .NET callers.
	Interop/TrieWrapper.cs - C# class used to wrap and expose trie matching
		library to .NET callers.
	Interop/Utils.cs - Utility class for shared internal methods.
	Interop/Properties/AssemblyInfo.cs - DLL header information.

	Trie/FiftyOne.Mobile.Detection.Provider.Trie.vcxproj - C library project.
	Trie/FuncsTrieDll.c - Dll methods accessible to any windows library.

	Pattern/FiftyOne.Mobile.Detection.Provider.Pattern.vcxproj - C lib
		project.
	Pattern/FuncsPatternDll.c - Dll methods accessible to any windows library.
	Pattern/PreBuild.bat - Used to create platform specific char tables for
		regexes.

	Demo/FiftyOne.Mobile.Detection.Demo.csproj - Demo web site using the
		Interop assembly to request properties associated with the requesting
		device.
	Demo/Default.aspx.* - Demo web page used to display properties. See these
		files for examples of how to create providers and retrieve properties.
	Demo/Properties/AssemblyInfo.cs - Project header information.

	Performance/FiftyOne.Mobile.Detection.Performance.vcxproj - Project file
		for the multi threaded windows command line executable.
	Performance/Performance.cpp - Main class for the executable.
	Performance/*.cpp & *.h - Related files to the C++ programme.

	x64Build.bat - Uses the Visual Studio compiler to build a x64 library.
	x86Build.bat - Uses the Visual Studio compiler to build a x86 library.
	FiftyOne.Mobile.Detection.Provider.sln - Visual Studio 2010 solution
		including demonstration web site and single threaded command line
		executables.
	FiftyOne.Mobile.Detection.Performance.sln - Visual Studio 2010 solution
		for the multi threaded performance test application.


Trie Data - Download
----------------------

The data files used with the trie matching method contain 10s of millions of
index strings. As a result the files are too large to be distributed with this
package. See the readme.txt file in the data folder for download instructions.

The trie data file does not need to be downloaded if only the pattern method
is required.


Trie Data - File Size
-----------------------

The trie data file is very large as it contains 10s of millions of index
strings. If the data file is larger than 2,147,483,647 bytes it is won't
be loaded into memory on a 32 bit architecture. This is not a problem for
the Lite format data file. However if using the Premium data file which
exceeds this limit use only 64 bit versions of the following examples.


Windows .NET - Wrapper & Demo Web Site
--------------------------------------

All Windows specific files are located in the windows folder. They rely on
Visual Studio 2010 or greater to build.

Execute the x64Build.bat or x86Build.bat files to compiler a 32 or 64 bit
version of the DLLs.

3 DLLs are compiled and placed in the following directories.

1. windows/Demo/bin/FiftyOne.Mobile.Detection.Provider.Pattern.dll
2. windows/Demo/bin/FiftyOne.Mobile.Detection.Provider.Trie.dll
3. windows/Demo/bin/FiftyOne.Mobile.Detection.Provider.Interop.dll

1.	The "Pattern" DLL is a self-contained detection provider using the pattern
	matching method. The FuncsPatternDll.c file contains the external
	interfaces.

2.	The "Trie" DLL is a detection provider using the trie matching method. A
	data file located in the data folder needs to be used with this DLL. The
	FuncsTrieDll.c file contain the external interfaces.

3.	The "Interop" DLL is a Common Language Runtime inter operation interface to
	the previous two DLLs. It should be used with .NET code.

Alternatively the FiftyOne.Mobile.Detection.Provider.sln can be opened in
Visual Studio 2010 or greater. This also includes an example web site with a
single page which displays the values returned for the requesting device from
both the Pattern and Trie providers.

Important: Before starting the example web site check the Default.aspx.cs file
to ensure the path to the Trie data file is set correctly. Alternatively
comment out the Trie provider.

Note: The windows C compiler can take upto 20 minutes to compile. GCC is
considerably faster.


Windows Command Line
--------------------

Execute the Win32Build.bat or Win64Build.bat files in the root folder to build
a command line executable using the Visual Studio compiler.

Execute the WinGCCBuild.bat file to compile the same executable using the GCC
compiler through CygWin or MinGW if installed. The relevant PATH file should be
configured before use.

4 executable are placed in the root folder. See Instructions further down this
document for more details.

ProcPat.exe		Stdin and Stdout process.
ProcTrie.exe

PerfPat.exe		Performance test executable.
PerfTrie.exe

Note: The windows C compiler can take upto 20 minutes to compile. GCC is
considerably faster.


Windows Multi Threaded Performance Measurement
----------------------------------------------

A slightly modifed version of PerfTrie.exe is created from the
FiftyOne.Mobile.Detection.Performance.sln Visual Studio project. A command line
executable is built which takes a Trie data file and file of user agents as
input. 4 threads are started to read and process the user agents input file in
parallel. Once complete it returns the average number of detections performed
per second.

Performance.exe TrieDataFile UserAgentsFile

DataFile		See ProcPat

UserAgentsFile	See PerfPat

Example:		Performance.exe 51Degrees.mobi.trie.dat million.csv


Linux Command Line
------------------

The makefile provided in the root folder should be used to build the following
4 executable. See Instructions further down this document for more details
concerning how to use these executables.

ProcPat		Stdin and Stdout process.
ProcTrie

PerfPat		Performance test executable.
PerfTrie

Use the terminal to navigate to the root folder of the project and enter the
command "make" to build the executables.

The executables can then be run from the same folder using the following
commands.

./ProcPat [Properties]
./PerfPat UserAgentsFile [Properties]
./ProcTrie TrieDataFile [Properties]
./PerfTrie TrieDataFile UserAgentsFile [Properties]


Instructions
------------

ProcPat
-------

Starts a process which reads user agents from StdIn and returns CSV format
properties and values for the matching device via StdOut. Uses the pattern
matching detection routine.

If run from the command line type a user agent, or any string for testing,
followed by enter to view the matched device properties.

Provide an empty string to terminate the process.

ProcPat.exe [Properties]

[Properties]	A comma separated list of properties to be returned. If not
				provided Id will be used.

				For example: Id,IsMobile will return the Id of the matched
				device and True or False to indicate if the device is a mobile.

				http://51Degrees.mobi/Products/DeviceData/PropertyDictionary
				provide a list of valid properties.

Example:		ProcPat.exe Id,IsMobile

				Enter user agent strings to view the returned Id and IsMobile
				values.


PerfPat
-------

Runs a performance test using a single process and thread using a data file
of user agent strings as input. Uses the pattern matching detection routine
which is very memory efficient.

PerfPat.exe UserAgentsFile [Properties]

UserAgentsFile	Path to a list of user agents to be used in the performance
				test.

				http://51Degrees.mobi/Million.zip contains a test file of one
				million user agents.

[Properties]	See ProcPat

Example:		PerfPat.exe million.csv
				PerfPat.exe million.csv Id,IsMobile


ProcTrie
--------

Starts a process which reads user agents from StdIn and returns CSV format
properties and values for the matching device via StdOut. Uses the trie
matching detection routine.

If run from the command line type a user agent, or any string for testing,
followed by enter to view the matched device properties.

Provide an empty string to terminate the process.

ProcTrie.exe DataFile [Properties]

TrieDataFile	A source data file in trie format. A data file current at the
				time the zip file was created is included in data folder.

[Properties]	See ProcPat

Example:		ProcTrie.exe data\51Degrees.mobi.trie.dat
				ProcTrie.exe data\51Degrees.mobi.trie.dat Id,IsMobile

				Enter user agent strings to view the returned Id and IsMobile
				values.

PerfTrie
--------

Runs a performance test using a single process and thread using a data file
of user agent strings as input. Uses the trie matching detection routine
which is very fast, but uses a lot of memory.

PerfTrie.exe TrieDataFile UserAgentsFile [Properties]

TrieDataFile	See ProcPat

UserAgentsFile	See PerfPat

[Properties]	See ProcPat

Example:		PerfTrie.exe 51Degrees.mobi.trie.dat million.csv
				PerfTrie.exe 51Degrees.mobi.trie.dat million.csv Id,IsMobile

--- END ---
