/* *********************************************************************
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0.
 *
 * If a copy of the MPL was not distributed with this file, You can obtain
 * one at http://mozilla.org/MPL/2.0/.
 *
 * This Source Code Form is "Incompatible With Secondary Licenses", as
 * defined by the Mozilla Public License, v. 2.0.
 * ********************************************************************* */

#include "..\..\src\pattern\51Degrees.mobi.h"
#include "Windows.h"

#define EXTERN_DLL_EXPORT __declspec(dllexport)

EXTERN_DLL_EXPORT int __cdecl Init(LPCTSTR properties)
{
	return init((char*)properties);
}

EXTERN_DLL_EXPORT void __cdecl Destroy()
{
	destroy();
}

EXTERN_DLL_EXPORT LP __cdecl CreateWorkSet()
{
	Workset *ws = NULL;
	ws = createWorkset();
	return (LP)ws;
}

EXTERN_DLL_EXPORT void __cdecl FreeWorkSet(LP workSet)
{
	freeWorkset((Workset*)workSet);
}

EXTERN_DLL_EXPORT int __cdecl GetPropertiesCSV(LP workSet, LPCTSTR userAgent, LPTSTR result, DWORD resultLength)
{
	const Device *device;
	int i = -1;
	Workset *ws = (Workset*)workSet;

	// Copy the input user agent to the workset.
	do {
		i++;
		*(ws->input + i) = *(((char*)userAgent) + i);
	} while(*(((char*)userAgent) + i) != '\0' && i < MAXBUFFER);

	// Populate the result buffer with properties in CSV format if a
	// device was returned.
	device = getDevice(ws);
	if (device != NULL)
		return processDeviceCSV(device, (char*)result, resultLength);
	return 0;
}