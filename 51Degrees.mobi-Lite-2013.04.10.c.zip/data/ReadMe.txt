The Lite/Free trie data file is available to download separatly.

The file name is: 51Degrees.mobi-Lite-[date].trie.zip