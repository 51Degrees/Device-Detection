/**
 * Copyright (C) 2012 51Degrees.mobi Limited
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <limits.h>

#include "51Degrees.mobi.h"

#ifdef _DEBUG
#define PASSES 1
#else
#define PASSES 5
#endif

// Size of the character buffers
#define BUFFER 50000

// Number of detection to complete between reporting progress.
#define PROGRESS 50000

#define CLOCKS_PER_MS (CLOCKS_PER_SEC / 1000)

// Used for determining the max size of the loading bar.
int _max;

// Prints a progress bar
void printLoadBar(int count) {
	int i;

	printf("\r\t[");
	for (i = 0; i < count; i++) {
		printf("=");
	}

	for (i = 0; i < (_max / PROGRESS) - count; i++) {
		printf(" ");
	}
	printf("]");
}

// Execute a performance test using a file of null terminated useragent strings
// as input. If calibrate is true then the file is read but no detections
// are performed.
#pragma optimize("", off)
int performanceTest(char* fileName, int calibrate) {
	int count = 0, offset = 0;
	const char *result;
	char userAgent[BUFFER];
	int device = INT_MAX;
	int propertyIndex = getPropertyIndex("Id");
	FILE *inputFilePtr = fopen(fileName, "r");

	do {
		// Get the next character from the input.
		result = fgets(userAgent, BUFFER, inputFilePtr);

		// Break for an empty string or end of file.
		if (result == NULL && feof(inputFilePtr))
			break;

		// If we're not calibrating then get the device for the
		// useragent that has just been read.
		if (strlen(userAgent) < 1024 && calibrate == 0)
			device = getDeviceOffset(userAgent);

		// Increase the counter and reset the offset to
		// read the next user agent from the input.
		count++;

		// Print a progress marker.
		if (count % PROGRESS == 0) {
			printLoadBar(count / PROGRESS);

			// If in real detection mode then print the id of the device found
			// to prove it's actually doing something!
			if (calibrate == 0)
				printf(" %s", getValue(device, propertyIndex));
		}
	} while(1);
	_max = count;
	fclose(inputFilePtr);
	printf("\n\n");
	return count;
}
#pragma optimize("", on)

// Perform the test and return the average time.
clock_t performTest(char *fileName, int passes, int calibrate, char *test) {
	int pass, characters, iterations;
	clock_t start, total, passes_total = 0;
	fflush(stdout);

	// Perform a number of passes of the test.
	for(pass = 1; pass <= passes; pass++) {
		printf("%s pass %i of %i: \n\n", test, pass, passes);
		start = clock();
		iterations = performanceTest(fileName, calibrate);
		total = clock() - start + 1;
		passes_total += total;
	}
	return passes_total / pass;
}

// Performance test.
void performance(char *fileName) {
	float totalSec;
	clock_t
		init = performTest(fileName, 1, 1, "Caching Data"),
		calibration = performTest(fileName, PASSES, 1, "Calibrate"),
		test = performTest(fileName, PASSES, 0, "Detection test");

	// Time to complete.
	printf("Average detection time for total data set: %d ms\n", (int)((test - calibration) / CLOCKS_PER_MS));
	totalSec = test - calibration;
	printf("Average number of detections per second: %.0f\n", (float) (_max / totalSec) * CLOCKS_PER_SEC);
}

// Reduces a file path to file name only.
char *findFileNames(char *subject) {
	char *c = subject;
	char *hold = NULL;

	do {
		hold = strchr(c, '\\');
		if (hold == NULL) {
			return c;
		}
		else {
			c = hold + 1;
		}
	} while (1);
}

// Check that file exists.
int fileExists(char *fileName) {
	FILE *filePtr = fopen(fileName, "rb");
	if (filePtr != NULL)
		fclose(filePtr);
	return filePtr != NULL;
}

// The main method used by the command line test routine.
int main(int argc, char* argv[]) {
	printf("\n");
	printf("\t#############################################################\n");
    printf("\t#                                                           #\n");
    printf("\t#  This program can be used to test the performance of the  #\n");
    printf("\t#              51Degrees.mobi 'Trie' C API.                 #\n");
    printf("\t#                                                           #\n");
    printf("\t#   The test will read a list of User Agents and calculate  #\n");
    printf("\t#            the number of detections per second.           #\n");
    printf("\t#                                                           #\n");
	printf("\t#    Command line arguments should be a tree format data    #\n");
	printf("\t#   file and a csv file containing a list of user agents.   #\n");
	printf("\t#      A test file of 1 million can be downloaded from      #\n");
	printf("\t#            http://51degrees.mobi/million.zip              #\n");
	printf("\t#                                                           #\n");
    printf("\t#############################################################\n");

	if (argc > 2) {

		// Check the files exist.
		if (fileExists(argv[2]) == 0) {
			printf("\n\nFile '%s' does not found.", argv[2]);
			return 0;
		}
		if (fileExists(argv[1]) == 0) {
			printf("\n\nFile '%s' does not found.", argv[1]);
			return 0;
		}

		// Perform the tests now we know the files exist.
		if (init(argv[1], argc > 3 ? argv[3] : "Id") == 0) {
			printf("\n\nUseragents file is: %s\n\nData file is: %s\n\n",
				findFileNames(argv[2]),
				findFileNames(argv[1]));

			// Wait for a character to be pressed.
			printf("\nPress enter to start performance tests.\n");
			fgetc(stdin);

			performance(argv[2]);
			destroy();
		}
	}
}


