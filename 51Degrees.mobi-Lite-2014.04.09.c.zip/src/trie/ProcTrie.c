/**
 * Copyright (C) 2012 51Degrees.mobi Limited
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <stdio.h>
#include <string.h>

#include "51Degrees.mobi.h"

int main(int argc, char* argv[]) {
	char input[50000], output[50000];

	if (argc > 1) {
		if (init(argv[1], argc > 2 ? argv[2] : "Id") == 0) {
			gets(input);
			while(strlen(input) > 0) {
				processDeviceCSV(getDeviceOffset(input), output, 50000);
				printf("%s", output);

				// Flush buffers.
				fflush(stdin);
				fflush(stdout);

				// Get the next useragent.
				gets(input);
			}
			destroy();
		}
	}

	return 0;
}


